-- ══════════════════════════════════════════════
--  Sukary — سكري | MySQL Database Schema
-- ══════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS sukary CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sukary;

-- ──────────────────────────────────────────────
-- 1. المستخدمون (Users)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(60)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  name          VARCHAR(100),
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ──────────────────────────────────────────────
-- 2. الملف الشخصي (Profile)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS profile (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL UNIQUE,
  name         VARCHAR(100),
  dob          DATE,
  gender       VARCHAR(10),
  phone        VARCHAR(20),
  weight       DECIMAL(5,1),
  height       DECIMAL(5,1),
  dtype        VARCHAR(20)  DEFAULT 'type2',
  diag_year    YEAR,
  doctor       VARCHAR(100),
  doctor_phone VARCHAR(20),
  conditions   TEXT,
  allergies    TEXT,
  updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ──────────────────────────────────────────────
-- 3. الأهداف العلاجية (Goals)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS goals (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL UNIQUE,
  fast_min     INT  DEFAULT 70,
  fast_max     INT  DEFAULT 130,
  post_min     INT  DEFAULT 70,
  post_max     INT  DEFAULT 180,
  low_alert    INT  DEFAULT 70,
  high_alert   INT  DEFAULT 250,
  hba1c        DECIMAL(4,1),
  hba1c_last   DECIMAL(4,1),
  weight       DECIMAL(5,1),
  activity     VARCHAR(60),
  bp           VARCHAR(20),
  chol         VARCHAR(20),
  updated_at   DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ──────────────────────────────────────────────
-- 4. سجلات السكر اليومية (Daily Records)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS records (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT  NOT NULL,
  record_date   DATE NOT NULL,
  day_name      VARCHAR(20),
  -- الفطار
  fasting       DECIMAL(5,1),
  dose_f        DECIMAL(5,1),
  food_f        VARCHAR(255),
  after_f       DECIMAL(5,1),
  -- الغدا
  before_l      DECIMAL(5,1),
  dose_l        DECIMAL(5,1),
  food_l        VARCHAR(255),
  after_l       DECIMAL(5,1),
  -- العشا
  before_d      DECIMAL(5,1),
  dose_d        DECIMAL(5,1),
  food_d        VARCHAR(255),
  after_d       DECIMAL(5,1),
  -- قبل النوم
  sleep         DECIMAL(5,1),
  total_insulin DECIMAL(5,1),
  notes         TEXT,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_user_date (user_id, record_date),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ──────────────────────────────────────────────
-- 5. السناكس (Snacks)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS snacks (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT  NOT NULL,
  snack_date   DATE NOT NULL,
  snack_type   VARCHAR(30),
  snack_time   TIME,
  sugar_before DECIMAL(5,1),
  food         VARCHAR(255),
  carbs        DECIMAL(5,1),
  dose         DECIMAL(5,1),
  sugar_after  DECIMAL(5,1),
  note         TEXT,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ──────────────────────────────────────────────
-- 6. الأدوية (Medications)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS medications (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT NOT NULL,
  name       VARCHAR(100) NOT NULL,
  type       VARCHAR(30),
  dose       VARCHAR(50),
  timing     VARCHAR(30),
  freq       VARCHAR(20),
  note       TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ──────────────────────────────────────────────
-- 7. المواعيد الطبية (Appointments)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS appointments (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  user_id      INT NOT NULL,
  appt_date    DATE NOT NULL,
  appt_time    TIME,
  type         VARCHAR(30),
  place        VARCHAR(100),
  notes        TEXT,
  created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ──────────────────────────────────────────────
-- 8. سجل حاسبة الكربوهيدرات (Carb Calc Log)
-- ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS calc_log (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  log_date    DATE NOT NULL,
  meal_label  VARCHAR(60),
  items_json  TEXT,
  total_carbs DECIMAL(6,1),
  total_cal   INT,
  total_prot  DECIMAL(6,1),
  total_fat   DECIMAL(6,1),
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ──────────────────────────────────────────────
-- بيانات تجريبية (Demo user — يمكن حذفها)
-- ──────────────────────────────────────────────
-- password = "demo123"  (bcrypt hash)
INSERT IGNORE INTO users (username, password_hash, name)
VALUES ('demo', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'مستخدم تجريبي');
