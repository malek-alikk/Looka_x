// ══════════════════════════════════════════════
//  sukary-api.js — API Client
//  بيعوض localStorage بـ MySQL API calls
// ══════════════════════════════════════════════

const API = {
  base: './api',

  async get(endpoint) {
    const r = await fetch(`${this.base}/${endpoint}`, { credentials: 'include' });
    if (r.status === 401) { showLogin(); return null; }
    return r.json();
  },

  async post(endpoint, data) {
    const r = await fetch(`${this.base}/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(data)
    });
    if (r.status === 401) { showLogin(); return null; }
    return r.json();
  },

  async put(endpoint, data) {
    const r = await fetch(`${this.base}/${endpoint}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify(data)
    });
    if (r.status === 401) { showLogin(); return null; }
    return r.json();
  },

  async del(endpoint) {
    const r = await fetch(`${this.base}/${endpoint}`, {
      method: 'DELETE',
      credentials: 'include'
    });
    if (r.status === 401) { showLogin(); return null; }
    return r.json();
  }
};

// ══════════════════════════════════════════════
//  Auth
// ══════════════════════════════════════════════
async function login(username, password) {
  const res = await API.post('auth.php?action=login', { username, password });
  if (res?.ok) {
    hideLogin();
    await initApp();
  } else {
    document.getElementById('login-error').textContent = res?.error || 'حصل خطأ';
  }
}

async function register(username, password, name) {
  const res = await API.post('auth.php?action=register', { username, password, name });
  if (res?.ok) {
    hideLogin();
    await initApp();
  } else {
    document.getElementById('login-error').textContent = res?.error || 'حصل خطأ';
  }
}

async function logout() {
  await API.post('auth.php?action=logout', {});
  window.location.href = 'index.html';
}

function showLogin() {
  window.location.href = 'index.html';
}

function hideLogin() {
  document.getElementById('login-screen').style.display = 'none';
  document.querySelector('.topbar').style.display = '';
  document.querySelector('.sidebar').style.display = '';
  document.querySelector('.main').style.display = '';
  document.getElementById('bottomNav').style.display = '';
}

// ══════════════════════════════════════════════
//  Records — يعوض localStorage st_records
// ══════════════════════════════════════════════
async function loadRecordsFromDB() {
  const data = await API.get('records.php');
  if (!data) return;
  records = data.filter(Boolean);
  renderDashboard();
  renderRecords();
  renderReport();
}

// save() → بقت async وبتعمل upsert
async function save() {
  // مش بتحفظ كل حاجة دفعة واحدة — كل function بتحفظ نفسها
  // الـ function دي اتبقت placeholder
}

async function saveQuick() {
  const date = document.getElementById('q-date').value;
  if (!date) { toast('⚠️ اختار التاريخ أولاً'); return; }
  const day = DAYS[new Date(date).getDay()];
  const entry = {
    date, day,
    fasting:  document.getElementById('q-fasting').value,
    doseF:    document.getElementById('q-doseF').value,
    foodF:    document.getElementById('q-foodF').value,
    afterF:   document.getElementById('q-afterF').value,
    beforeL:  document.getElementById('q-beforeL').value,
    doseL:    document.getElementById('q-doseL').value,
    foodL:    document.getElementById('q-foodL').value,
    afterL:   document.getElementById('q-afterL').value,
    beforeD:  document.getElementById('q-beforeD').value,
    doseD:    document.getElementById('q-doseD').value,
    foodD:    document.getElementById('q-foodD').value,
    afterD:   document.getElementById('q-afterD').value,
    sleep:    document.getElementById('q-sleep').value,
    notes:    document.getElementById('q-notes').value,
  };
  const res = await API.post('records.php', entry);
  if (res) {
    // حدّث الـ array المحلي
    records = records.filter(r => r.date !== date);
    records.unshift(res);
    records.sort((a, b) => b.date.localeCompare(a.date));
    renderDashboard(); renderRecords();
    toast('✅ تم حفظ اليوم!');
  } else {
    toast('❌ فشل الحفظ — تحقق من الاتصال');
  }
}

async function saveEdit() {
  const i   = parseInt(document.getElementById('edit-idx').value);
  const rec = records[i];
  if (!rec) return;
  const id  = rec.id;
  const b   = {
    date:    document.getElementById('edit-date').value,
    day:     document.getElementById('edit-day').value,
    fasting: document.getElementById('edit-fasting').value,
    doseF:   document.getElementById('edit-doseF').value,
    foodF:   document.getElementById('edit-foodF').value,
    afterF:  document.getElementById('edit-afterF').value,
    beforeL: document.getElementById('edit-beforeL').value,
    doseL:   document.getElementById('edit-doseL').value,
    foodL:   document.getElementById('edit-foodL').value,
    afterL:  document.getElementById('edit-afterL').value,
    beforeD: document.getElementById('edit-beforeD').value,
    doseD:   document.getElementById('edit-doseD').value,
    foodD:   document.getElementById('edit-foodD').value,
    afterD:  document.getElementById('edit-afterD').value,
    sleep:   document.getElementById('edit-sleep').value,
    notes:   document.getElementById('edit-notes').value,
  };
  const res = await API.put(`records.php?id=${id}`, b);
  if (res?.ok) {
    records[i] = { ...records[i], ...b };
    renderRecords(); renderDashboard();
    closeModal();
    toast('✅ تم التعديل');
  } else {
    toast('❌ فشل التعديل');
  }
}

async function deleteRec(i) {
  if (!confirm('مسح هذا السجل؟')) return;
  const id = records[i]?.id;
  if (!id) return;
  const res = await API.del(`records.php?id=${id}`);
  if (res?.ok) {
    records.splice(i, 1);
    renderRecords(); renderDashboard();
    toast('🗑️ تم الحذف');
  } else {
    toast('❌ فشل الحذف');
  }
}

// ══════════════════════════════════════════════
//  Snacks
// ══════════════════════════════════════════════
async function loadSnacksFromDB() {
  const data = await API.get('snacks.php');
  if (!data) return;
  snacks = data;
  renderSnacks();
}

async function saveSnack() {
  const idx = parseInt(document.getElementById('snack-edit-idx').value);
  const snack = {
    date:       document.getElementById('snack-date').value,
    type:       document.getElementById('snack-type').value,
    time:       document.getElementById('snack-time').value,
    sugarBefore:document.getElementById('snack-sugar-before').value,
    food:       document.getElementById('snack-food').value,
    carbs:      document.getElementById('snack-carbs').value,
    dose:       document.getElementById('snack-dose').value,
    sugarAfter: document.getElementById('snack-sugar-after').value,
    note:       document.getElementById('snack-note').value
  };
  if (idx >= 0) {
    // تعديل
    const id = snacks[idx].id;
    const res = await API.put(`snacks.php?id=${id}`, snack);
    if (res?.ok) {
      snacks[idx] = { ...snacks[idx], ...snack };
      toast('✅ تم تعديل السناك');
    }
  } else {
    // إضافة
    const res = await API.post('snacks.php', snack);
    if (res) {
      snacks.unshift(res);
      toast('✅ تم إضافة السناك');
    }
  }
  closeSnackModal();
  renderSnacks();
}

async function deleteSnack(i) {
  if (!confirm('مسح هذا السناك؟')) return;
  const id = snacks[i]?.id;
  const res = await API.del(`snacks.php?id=${id}`);
  if (res?.ok) {
    snacks.splice(i, 1);
    renderSnacks();
    toast('🗑️ تم الحذف');
  }
}

// ══════════════════════════════════════════════
//  Profile
// ══════════════════════════════════════════════
async function saveProfile() {
  const p = {
    name:        document.getElementById('prof-name').value,
    dob:         document.getElementById('prof-dob').value,
    gender:      document.getElementById('prof-gender').value,
    phone:       document.getElementById('prof-phone').value,
    weight:      document.getElementById('prof-weight').value,
    height:      document.getElementById('prof-height').value,
    dtype:       document.getElementById('prof-dtype').value,
    diagYear:    document.getElementById('prof-diag-year').value,
    doctor:      document.getElementById('prof-doctor').value,
    doctorPhone: document.getElementById('prof-doctor-phone').value,
    conditions:  document.getElementById('prof-conditions').value,
    allergies:   document.getElementById('prof-allergies').value
  };
  const res = await API.post('user.php?section=profile', p);
  if (res?.ok) {
    updateIDCard(p);
    updateSubtitle(p);
    toast('✅ تم حفظ الملف الشخصي');
  } else {
    toast('❌ فشل الحفظ');
  }
}

async function loadProfile() {
  const p = await API.get('user.php?section=profile');
  if (!p) return;
  const fields = {
    'prof-name': p.name, 'prof-dob': p.dob, 'prof-gender': p.gender,
    'prof-phone': p.phone, 'prof-weight': p.weight, 'prof-height': p.height,
    'prof-dtype': p.dtype, 'prof-diag-year': p.diagYear,
    'prof-doctor': p.doctor, 'prof-doctor-phone': p.doctorPhone,
    'prof-conditions': p.conditions, 'prof-allergies': p.allergies
  };
  Object.entries(fields).forEach(([id, val]) => {
    const el = document.getElementById(id);
    if (el && val) el.value = val;
  });
  updateIDCard(p);
  if (p.weight && p.height) calcBMI();
  updateSubtitle(p);
}

function updateSubtitle(p) {
  const labels = { type1:'النوع الأول', type2:'النوع الثاني', gestational:'سكري الحمل', other:'ما قبل السكري' };
  const sub = document.getElementById('topSubtitle');
  if (sub) sub.textContent = 'متابعة السكري' + (p?.dtype && labels[p.dtype] ? ' — ' + labels[p.dtype] : '');
}

// ══════════════════════════════════════════════
//  Goals
// ══════════════════════════════════════════════
async function saveGoals() {
  const g = {
    fastMin: document.getElementById('goal-fast-min').value,
    fastMax: document.getElementById('goal-fast-max').value,
    postMin: document.getElementById('goal-post-min').value,
    postMax: document.getElementById('goal-post-max').value,
    lowAlert: document.getElementById('goal-low-alert').value,
    highAlert: document.getElementById('goal-high-alert').value,
    hba1c: document.getElementById('goal-hba1c').value,
    hba1cLast: document.getElementById('goal-hba1c-last').value,
    weight: document.getElementById('goal-weight').value,
    activity: document.getElementById('goal-activity').value,
    bp: document.getElementById('goal-bp').value,
    chol: document.getElementById('goal-chol').value
  };
  const res = await API.post('user.php?section=goals', g);
  if (res?.ok) {
    updateGoalsStats(g);
    renderGoalsProgress(g);
    toast('✅ تم حفظ الأهداف العلاجية');
  } else {
    toast('❌ فشل الحفظ');
  }
}

async function loadGoals() {
  const g = await API.get('user.php?section=goals');
  if (!g) return;
  const fields = {
    'goal-fast-min': g.fastMin, 'goal-fast-max': g.fastMax,
    'goal-post-min': g.postMin, 'goal-post-max': g.postMax,
    'goal-low-alert': g.lowAlert, 'goal-high-alert': g.highAlert,
    'goal-hba1c': g.hba1c, 'goal-hba1c-last': g.hba1cLast,
    'goal-weight': g.weight, 'goal-activity': g.activity,
    'goal-bp': g.bp, 'goal-chol': g.chol
  };
  Object.entries(fields).forEach(([id, val]) => {
    const el = document.getElementById(id);
    if (el && val) el.value = val;
  });
  updateGoalsStats(g);
  renderGoalsProgress(g);
}

// ══════════════════════════════════════════════
//  Medications
// ══════════════════════════════════════════════
async function addMedication() {
  const name = document.getElementById('med-name').value.trim();
  if (!name) { toast('⚠️ أدخل اسم الدواء'); return; }
  const med = {
    name,
    type:   document.getElementById('med-type').value,
    dose:   document.getElementById('med-dose').value,
    timing: document.getElementById('med-timing').value,
    freq:   document.getElementById('med-freq').value,
    note:   document.getElementById('med-note').value
  };
  const res = await API.post('user.php?section=medications', med);
  if (res?.ok) {
    medications.push({ id: res.id, ...med });
    document.getElementById('med-name').value = '';
    document.getElementById('med-dose').value = '';
    document.getElementById('med-note').value = '';
    renderMedications();
    toast('✅ تم إضافة الدواء');
  }
}

async function deleteMedication(id) {
  await API.del(`user.php?section=medications&id=${id}`);
  medications = medications.filter(m => m.id !== id);
  renderMedications();
  toast('🗑️ تم حذف الدواء');
}

async function loadMedications() {
  const data = await API.get('user.php?section=medications');
  if (!data) return;
  medications = data;
  renderMedications();
}

// ══════════════════════════════════════════════
//  Appointments
// ══════════════════════════════════════════════
async function addAppointment() {
  const date = document.getElementById('appt-date').value;
  if (!date) { toast('⚠️ اختار التاريخ'); return; }
  const appt = {
    date,
    time:  document.getElementById('appt-time').value,
    type:  document.getElementById('appt-type').value,
    place: document.getElementById('appt-place').value,
    notes: document.getElementById('appt-notes').value
  };
  const res = await API.post('user.php?section=appointments', appt);
  if (res?.ok) {
    appointments.push({ id: res.id, ...appt });
    document.getElementById('appt-date').value  = '';
    document.getElementById('appt-place').value = '';
    document.getElementById('appt-notes').value = '';
    renderAppointments();
    toast('✅ تم حفظ الموعد');
  }
}

async function deleteAppointment(id) {
  await API.del(`user.php?section=appointments&id=${id}`);
  appointments = appointments.filter(a => a.id !== id);
  renderAppointments();
  toast('🗑️ تم حذف الموعد');
}

async function loadAppointments() {
  const data = await API.get('user.php?section=appointments');
  if (!data) return;
  appointments = data;
  renderAppointments();
}

// ══════════════════════════════════════════════
//  Calc Log
// ══════════════════════════════════════════════
async function saveMealToLog() {
  if (!mealItems.length) { toast('⚠️ الوجبة فارغة'); return; }
  let totCarb=0, totCal=0, totProt=0, totFat=0;
  mealItems.forEach(x => { totCarb+=x.carb; totCal+=+x.cal; totProt+=x.prot; totFat+=x.fat; });
  const mealTypeEl = document.getElementById('calc-meal-type');
  const dateEl     = document.getElementById('calc-date');
  const mealType   = mealTypeEl ? mealTypeEl.value : 'breakfast';
  const date       = dateEl ? dateEl.value : new Date().toISOString().split('T')[0];
  const labels = {breakfast:'🍳 فطار','morning-snack':'🍎 سناك ص',lunch:'☀️ غدا','afternoon-snack':'🧃 سناك م',dinner:'🌙 عشا','night-snack':'🌛 سناك ليل'};
  const entry = {
    date, mealLabel: labels[mealType] || mealType,
    items: mealItems,
    totalCarbs: +totCarb.toFixed(1), totalCal: Math.round(totCal),
    totalProt: +totProt.toFixed(1), totalFat: +totFat.toFixed(1),
  };
  const res = await API.post('user.php?section=calclog', entry);
  if (res?.ok) {
    calcLog.unshift({ id: res.id, ...entry, items: mealItems.map(x => x.name).join('، '),
      carb: entry.totalCarbs, cal: entry.totalCal, prot: entry.totalProt, fat: entry.totalFat });
    renderCalcLog();
    clearMeal();
    toast('✅ تم حفظ الوجبة في السجل');
  }
}

async function deleteCalcLog(id) {
  await API.del(`user.php?section=calclog&id=${id}`);
  calcLog = calcLog.filter(x => x.id !== id);
  renderCalcLog();
  toast('🗑️ تم حذف السجل');
}

async function clearCalcLog() {
  if (!confirm('هتمسح كل سجل الوجبات. متأكد؟')) return;
  for (const x of calcLog) await API.del(`user.php?section=calclog&id=${x.id}`);
  calcLog = [];
  renderCalcLog();
  toast('🗑️ تم مسح السجل كامل');
}

async function loadCalcLog() {
  const data = await API.get('user.php?section=calclog');
  if (!data) return;
  calcLog = data.map(l => ({
    ...l,
    carb: l.totalCarbs, cal: l.totalCal, prot: l.totalProt, fat: l.totalFat,
    items: Array.isArray(l.items) ? l.items.map(x => x.name || x).join('، ') : (l.items || '')
  }));
  renderCalcLog();
}

// ══════════════════════════════════════════════
//  Init App (بعد login)
// ══════════════════════════════════════════════
async function initApp() {
  await Promise.all([
    loadRecordsFromDB(),
    loadSnacksFromDB(),
    loadProfile(),
    loadGoals(),
    loadMedications(),
    loadAppointments(),
    loadCalcLog(),
  ]);
  const d = document.getElementById('calc-date');
  if (d) d.value = new Date().toISOString().split('T')[0];
}
