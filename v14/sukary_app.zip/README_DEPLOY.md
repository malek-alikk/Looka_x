# 🚀 دليل رفع مشروع سكري على السيرفر

## المتطلبات
- PHP 8.0 أو أحدث
- MySQL 5.7 أو أحدث (أو MariaDB 10.3+)
- Apache مع `mod_rewrite` و `mod_headers` مفعّلين

---

## خطوات الرفع

### 1. إنشاء قاعدة البيانات
في phpMyAdmin أو عبر SSH:
```sql
CREATE DATABASE sukary CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
ثم استورد ملف `db.sql` على قاعدة البيانات الجديدة.

### 2. تعديل بيانات الاتصال
افتح ملف `api/config.php` وعدّل:
```php
define('DB_HOST', 'localhost');     // عادةً localhost
define('DB_NAME', 'sukary');        // اسم قاعدة البيانات اللي أنشأتها
define('DB_USER', 'YOUR_USER');     // ← اسم مستخدم MySQL بتاعك
define('DB_PASS', 'YOUR_PASSWORD'); // ← الباسورد
define('SESSION_KEY', 'اكتب_هنا_string_عشوائي_طويل');
```

### 3. رفع الملفات
ارفع كل الملفات على السيرفر (مثلاً في `public_html/sukary/`):
```
sukary/
├── api/
│   ├── auth.php
│   ├── config.php
│   ├── records.php
│   ├── snacks.php
│   └── user.php
├── .htaccess
├── db.sql          ← مش لازم ترفعه (أمان أكتر)
├── index.html
├── sukary-api.js
└── sukary.png
```

### 4. تفعيل HTTPS (لو السيرفر يدعمه)
في `.htaccess` شيل الـ comment عن السطور دي:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteCond %{HTTPS} off
  RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</IfModule>
```

### 5. تحديد CORS (اختياري لكن أفضل)
في `api/config.php` غيّر:
```php
$allowed_origin = getenv('ALLOWED_ORIGIN') ?: 'https://yourdomain.com';
```

---

## المستخدم التجريبي
- **Username:** `demo`
- **Password:** `demo123`

احذفه من قاعدة البيانات بعد التجربة:
```sql
DELETE FROM users WHERE username = 'demo';
```

---

## ✅ Checklist قبل الإطلاق
- [ ] غيّرت بيانات DB في `config.php`
- [ ] غيّرت `SESSION_KEY` لـ string عشوائي
- [ ] استوردت `db.sql` في قاعدة البيانات
- [ ] حذفت المستخدم التجريبي `demo`
- [ ] فعّلت HTTPS لو متاح
- [ ] تأكدت إن `config.php` مش بيتقرأ مباشرة من المتصفح
