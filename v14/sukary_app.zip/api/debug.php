<?php
// ملف مؤقت للتشخيص — احذفه بعد ما تحل المشكلة
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json; charset=utf-8');

$results = [];

// 1. PHP Version
$results['php_version'] = phpversion();

// 2. اختبار الاتصال بـ DB
try {
    $pdo = new PDO(
        'mysql:host=localhost;dbname=malek2026_sukary;charset=utf8mb4',
        'malek2026',
        'Malek@2026',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $results['db_connection'] = 'OK';

    // 3. تأكد إن الجداول موجودة
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $results['tables'] = $tables;

} catch (PDOException $e) {
    $results['db_connection'] = 'FAILED';
    $results['db_error'] = $e->getMessage();
}

// 4. اختبار الـ session
try {
    session_set_cookie_params([
        'lifetime' => 86400,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_name('sukary_debug');
    session_start();
    $_SESSION['test'] = 'ok';
    $results['session'] = 'OK';
} catch (Exception $e) {
    $results['session'] = 'FAILED: ' . $e->getMessage();
}

echo json_encode($results, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
