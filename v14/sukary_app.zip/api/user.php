<?php
// ══════════════════════════════════════════════
//  api/user.php — Profile, Goals, Medications,
//               Appointments, CalcLog
//
//  GET/POST /api/user.php?section=profile
//  GET/POST /api/user.php?section=goals
//  GET      /api/user.php?section=medications
//  POST     /api/user.php?section=medications        → إضافة
//  DELETE   /api/user.php?section=medications&id=N   → حذف
//  GET      /api/user.php?section=appointments
//  POST     /api/user.php?section=appointments       → إضافة
//  DELETE   /api/user.php?section=appointments&id=N  → حذف
//  GET      /api/user.php?section=calclog
//  POST     /api/user.php?section=calclog            → إضافة
//  DELETE   /api/user.php?section=calclog&id=N       → حذف
// ══════════════════════════════════════════════
require_once __DIR__ . '/config.php';

$uid     = getCurrentUserId();
$method  = $_SERVER['REQUEST_METHOD'];
$section = $_GET['section'] ?? '';
$pdo     = getDB();

// ══════════════════════════════════════════════
// PROFILE
// ══════════════════════════════════════════════
if ($section === 'profile') {
    if ($method === 'GET') {
        $stmt = $pdo->prepare('SELECT * FROM profile WHERE user_id = ?');
        $stmt->execute([$uid]);
        $row = $stmt->fetch();
        if (!$row) {
            // أنشئها إذا مكانتش موجودة
            $pdo->prepare('INSERT IGNORE INTO profile (user_id) VALUES (?)')->execute([$uid]);
            $row = ['user_id' => $uid];
        }
        json_out([
            'name'        => $row['name']         ?? '',
            'dob'         => $row['dob']           ?? '',
            'gender'      => $row['gender']        ?? '',
            'phone'       => $row['phone']         ?? '',
            'weight'      => $row['weight']        ?? '',
            'height'      => $row['height']        ?? '',
            'dtype'       => $row['dtype']         ?? 'type2',
            'diagYear'    => $row['diag_year']     ?? '',
            'doctor'      => $row['doctor']        ?? '',
            'doctorPhone' => $row['doctor_phone']  ?? '',
            'conditions'  => $row['conditions']    ?? '',
            'allergies'   => $row['allergies']     ?? '',
        ]);
    }
    if ($method === 'POST') {
        $b = get_body();
        $sql = '
            INSERT INTO profile (user_id, name, dob, gender, phone, weight, height, dtype, diag_year, doctor, doctor_phone, conditions, allergies)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE
                name=VALUES(name), dob=VALUES(dob), gender=VALUES(gender),
                phone=VALUES(phone), weight=VALUES(weight), height=VALUES(height),
                dtype=VALUES(dtype), diag_year=VALUES(diag_year), doctor=VALUES(doctor),
                doctor_phone=VALUES(doctor_phone), conditions=VALUES(conditions),
                allergies=VALUES(allergies), updated_at=CURRENT_TIMESTAMP
        ';
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $uid,
            $b['name']        ?? null,
            $b['dob']         ?: null,
            $b['gender']      ?? null,
            $b['phone']       ?? null,
            $b['weight']      ?: null,
            $b['height']      ?: null,
            $b['dtype']       ?? 'type2',
            $b['diagYear']    ?: null,
            $b['doctor']      ?? null,
            $b['doctorPhone'] ?? null,
            $b['conditions']  ?? null,
            $b['allergies']   ?? null,
        ]);
        json_out(['ok' => true]);
    }
}

// ══════════════════════════════════════════════
// GOALS
// ══════════════════════════════════════════════
if ($section === 'goals') {
    if ($method === 'GET') {
        $stmt = $pdo->prepare('SELECT * FROM goals WHERE user_id = ?');
        $stmt->execute([$uid]);
        $row = $stmt->fetch();
        if (!$row) {
            $pdo->prepare('INSERT IGNORE INTO goals (user_id) VALUES (?)')->execute([$uid]);
            $row = [];
        }
        json_out([
            'fastMin'  => $row['fast_min']   ?? 70,
            'fastMax'  => $row['fast_max']   ?? 130,
            'postMin'  => $row['post_min']   ?? 70,
            'postMax'  => $row['post_max']   ?? 180,
            'lowAlert' => $row['low_alert']  ?? 70,
            'highAlert'=> $row['high_alert'] ?? 250,
            'hba1c'    => $row['hba1c']      ?? '',
            'hba1cLast'=> $row['hba1c_last'] ?? '',
            'weight'   => $row['weight']     ?? '',
            'activity' => $row['activity']   ?? '',
            'bp'       => $row['bp']         ?? '',
            'chol'     => $row['chol']       ?? '',
        ]);
    }
    if ($method === 'POST') {
        $b = get_body();
        $sql = '
            INSERT INTO goals (user_id, fast_min, fast_max, post_min, post_max, low_alert, high_alert, hba1c, hba1c_last, weight, activity, bp, chol)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE
                fast_min=VALUES(fast_min), fast_max=VALUES(fast_max),
                post_min=VALUES(post_min), post_max=VALUES(post_max),
                low_alert=VALUES(low_alert), high_alert=VALUES(high_alert),
                hba1c=VALUES(hba1c), hba1c_last=VALUES(hba1c_last),
                weight=VALUES(weight), activity=VALUES(activity),
                bp=VALUES(bp), chol=VALUES(chol), updated_at=CURRENT_TIMESTAMP
        ';
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $uid,
            $b['fastMin']   ?: 70, $b['fastMax']   ?: 130,
            $b['postMin']   ?: 70, $b['postMax']   ?: 180,
            $b['lowAlert']  ?: 70, $b['highAlert'] ?: 250,
            $b['hba1c']     ?: null, $b['hba1cLast'] ?: null,
            $b['weight']    ?: null, $b['activity']  ?: null,
            $b['bp']        ?: null, $b['chol']      ?: null,
        ]);
        json_out(['ok' => true]);
    }
}

// ══════════════════════════════════════════════
// MEDICATIONS
// ══════════════════════════════════════════════
if ($section === 'medications') {
    if ($method === 'GET') {
        $stmt = $pdo->prepare('SELECT * FROM medications WHERE user_id = ? ORDER BY id');
        $stmt->execute([$uid]);
        json_out($stmt->fetchAll());
    }
    if ($method === 'POST') {
        $b = get_body();
        if (empty($b['name'])) json_out(['error' => 'اسم الدواء مطلوب'], 400);
        $stmt = $pdo->prepare(
            'INSERT INTO medications (user_id, name, type, dose, timing, freq, note) VALUES (?,?,?,?,?,?,?)'
        );
        $stmt->execute([
            $uid, $b['name'], $b['type'] ?? null, $b['dose'] ?? null,
            $b['timing'] ?? null, $b['freq'] ?? null, $b['note'] ?? null
        ]);
        json_out(['ok' => true, 'id' => $pdo->lastInsertId()], 201);
    }
    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM medications WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
        json_out(['ok' => true]);
    }
}

// ══════════════════════════════════════════════
// APPOINTMENTS
// ══════════════════════════════════════════════
if ($section === 'appointments') {
    if ($method === 'GET') {
        $stmt = $pdo->prepare('SELECT * FROM appointments WHERE user_id = ? ORDER BY appt_date ASC, appt_time ASC');
        $stmt->execute([$uid]);
        $rows = $stmt->fetchAll();
        json_out(array_map(fn($r) => [
            'id'    => (int)$r['id'],
            'date'  => $r['appt_date'],
            'time'  => $r['appt_time'],
            'type'  => $r['type'],
            'place' => $r['place'],
            'notes' => $r['notes'],
        ], $rows));
    }
    if ($method === 'POST') {
        $b = get_body();
        if (empty($b['date'])) json_out(['error' => 'التاريخ مطلوب'], 400);
        $stmt = $pdo->prepare(
            'INSERT INTO appointments (user_id, appt_date, appt_time, type, place, notes) VALUES (?,?,?,?,?,?)'
        );
        $stmt->execute([
            $uid, $b['date'], $b['time'] ?: null, $b['type'] ?? null,
            $b['place'] ?? null, $b['notes'] ?? null
        ]);
        json_out(['ok' => true, 'id' => $pdo->lastInsertId()], 201);
    }
    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM appointments WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
        json_out(['ok' => true]);
    }
}

// ══════════════════════════════════════════════
// CALC LOG (حاسبة الكربوهيدرات)
// ══════════════════════════════════════════════
if ($section === 'calclog') {
    if ($method === 'GET') {
        $stmt = $pdo->prepare(
            'SELECT * FROM calc_log WHERE user_id = ? ORDER BY log_date DESC, id DESC LIMIT 100'
        );
        $stmt->execute([$uid]);
        $rows = $stmt->fetchAll();
        json_out(array_map(fn($r) => [
            'id'         => (int)$r['id'],
            'date'       => $r['log_date'],
            'mealLabel'  => $r['meal_label'],
            'items'      => json_decode($r['items_json'] ?? '[]', true),
            'totalCarbs' => $r['total_carbs'],
            'totalCal'   => (int)$r['total_cal'],
            'totalProt'  => $r['total_prot'],
            'totalFat'   => $r['total_fat'],
        ], $rows));
    }
    if ($method === 'POST') {
        $b = get_body();
        $stmt = $pdo->prepare('
            INSERT INTO calc_log (user_id, log_date, meal_label, items_json, total_carbs, total_cal, total_prot, total_fat)
            VALUES (?,?,?,?,?,?,?,?)
        ');
        $stmt->execute([
            $uid,
            $b['date']       ?? date('Y-m-d'),
            $b['mealLabel']  ?? null,
            json_encode($b['items'] ?? [], JSON_UNESCAPED_UNICODE),
            $b['totalCarbs'] ?: null,
            $b['totalCal']   ?: null,
            $b['totalProt']  ?: null,
            $b['totalFat']   ?: null,
        ]);
        json_out(['ok' => true, 'id' => $pdo->lastInsertId()], 201);
    }
    if ($method === 'DELETE') {
        $id = (int)($_GET['id'] ?? 0);
        $pdo->prepare('DELETE FROM calc_log WHERE id = ? AND user_id = ?')->execute([$id, $uid]);
        json_out(['ok' => true]);
    }
}

json_out(['error' => 'section مش معروف'], 400);
