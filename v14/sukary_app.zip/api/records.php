<?php
// ══════════════════════════════════════════════
//  api/records.php — سجلات السكر اليومية
//  GET    /api/records.php            → كل السجلات
//  GET    /api/records.php?date=YYYY-MM-DD → يوم معين
//  POST   /api/records.php            → حفظ/تحديث يوم (upsert)
//  PUT    /api/records.php?id=N       → تعديل سجل
//  DELETE /api/records.php?id=N       → حذف سجل
// ══════════════════════════════════════════════
require_once __DIR__ . '/config.php';

$uid    = getCurrentUserId();
$method = $_SERVER['REQUEST_METHOD'];
$pdo    = getDB();

// ──────────────────────────────────────────────
// GET — جلب السجلات
// ──────────────────────────────────────────────
if ($method === 'GET') {
    if (isset($_GET['date'])) {
        $stmt = $pdo->prepare('SELECT * FROM records WHERE user_id = ? AND record_date = ?');
        $stmt->execute([$uid, $_GET['date']]);
        $row = $stmt->fetch();
        json_out($row ? formatRecord($row) : null);
    }
    // كل السجلات مرتبة تنازلياً
    $limit  = min((int)($_GET['limit']  ?? 365), 1000);
    $offset = (int)($_GET['offset'] ?? 0);
    $stmt   = $pdo->prepare(
        'SELECT * FROM records WHERE user_id = ? ORDER BY record_date DESC LIMIT ? OFFSET ?'
    );
    $stmt->execute([$uid, $limit, $offset]);
    $rows = $stmt->fetchAll();
    json_out(array_map('formatRecord', $rows));
}

// ──────────────────────────────────────────────
// POST — حفظ/تحديث يوم (upsert by date)
// ──────────────────────────────────────────────
if ($method === 'POST') {
    $b = get_body();
    if (empty($b['date'])) json_out(['error' => 'التاريخ مطلوب'], 400);

    $dF = (float)($b['doseF'] ?? 0);
    $dL = (float)($b['doseL'] ?? 0);
    $dD = (float)($b['doseD'] ?? 0);
    $total = $dF + $dL + $dD;

    $sql = '
        INSERT INTO records
            (user_id, record_date, day_name,
             fasting, dose_f, food_f, after_f,
             before_l, dose_l, food_l, after_l,
             before_d, dose_d, food_d, after_d,
             sleep, total_insulin, notes)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE
            day_name      = VALUES(day_name),
            fasting       = VALUES(fasting),
            dose_f        = VALUES(dose_f),
            food_f        = VALUES(food_f),
            after_f       = VALUES(after_f),
            before_l      = VALUES(before_l),
            dose_l        = VALUES(dose_l),
            food_l        = VALUES(food_l),
            after_l       = VALUES(after_l),
            before_d      = VALUES(before_d),
            dose_d        = VALUES(dose_d),
            food_d        = VALUES(food_d),
            after_d       = VALUES(after_d),
            sleep         = VALUES(sleep),
            total_insulin = VALUES(total_insulin),
            notes         = VALUES(notes),
            updated_at    = CURRENT_TIMESTAMP
    ';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $uid,
        $b['date'],
        $b['day']      ?? null,
        nv($b['fasting'] ?? ''),
        nv($b['doseF']   ?? ''),
        $b['foodF']    ?? null,
        nv($b['afterF']  ?? ''),
        nv($b['beforeL'] ?? ''),
        nv($b['doseL']   ?? ''),
        $b['foodL']    ?? null,
        nv($b['afterL']  ?? ''),
        nv($b['beforeD'] ?? ''),
        nv($b['doseD']   ?? ''),
        $b['foodD']    ?? null,
        nv($b['afterD']  ?? ''),
        nv($b['sleep']   ?? ''),
        $total ?: null,
        $b['notes']    ?? null,
    ]);

    // إرجاع السجل المحدث
    $stmt2 = $pdo->prepare('SELECT * FROM records WHERE user_id = ? AND record_date = ?');
    $stmt2->execute([$uid, $b['date']]);
    json_out(formatRecord($stmt2->fetch()));
}

// ──────────────────────────────────────────────
// PUT — تعديل سجل بالـ id
// ──────────────────────────────────────────────
if ($method === 'PUT') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) json_out(['error' => 'id مطلوب'], 400);
    $b = get_body();

    // تأكد إن السجل ده بتاع المستخدم ده
    $check = $pdo->prepare('SELECT id FROM records WHERE id = ? AND user_id = ?');
    $check->execute([$id, $uid]);
    if (!$check->fetch()) json_out(['error' => 'مش موجود'], 404);

    $dF = (float)($b['doseF'] ?? 0);
    $dL = (float)($b['doseL'] ?? 0);
    $dD = (float)($b['doseD'] ?? 0);
    $total = $dF + $dL + $dD;

    $sql = '
        UPDATE records SET
            record_date   = ?, day_name      = ?,
            fasting       = ?, dose_f         = ?, food_f  = ?, after_f  = ?,
            before_l      = ?, dose_l         = ?, food_l  = ?, after_l  = ?,
            before_d      = ?, dose_d         = ?, food_d  = ?, after_d  = ?,
            sleep         = ?, total_insulin  = ?, notes   = ?
        WHERE id = ? AND user_id = ?
    ';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $b['date']    ?? null, $b['day']      ?? null,
        nv($b['fasting'] ?? ''), nv($b['doseF'] ?? ''), $b['foodF'] ?? null, nv($b['afterF'] ?? ''),
        nv($b['beforeL'] ?? ''), nv($b['doseL'] ?? ''), $b['foodL'] ?? null, nv($b['afterL'] ?? ''),
        nv($b['beforeD'] ?? ''), nv($b['doseD'] ?? ''), $b['foodD'] ?? null, nv($b['afterD'] ?? ''),
        nv($b['sleep'] ?? ''), $total ?: null, $b['notes'] ?? null,
        $id, $uid
    ]);
    json_out(['ok' => true]);
}

// ──────────────────────────────────────────────
// DELETE
// ──────────────────────────────────────────────
if ($method === 'DELETE') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) json_out(['error' => 'id مطلوب'], 400);
    $stmt = $pdo->prepare('DELETE FROM records WHERE id = ? AND user_id = ?');
    $stmt->execute([$id, $uid]);
    json_out(['ok' => true, 'deleted' => $stmt->rowCount()]);
}

json_out(['error' => 'method مش مدعوم'], 405);

// ──────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────
function formatRecord(array $r): array {
    return [
        'id'           => (int)$r['id'],
        'date'         => $r['record_date'],
        'day'          => $r['day_name'],
        'fasting'      => $r['fasting'],
        'doseF'        => $r['dose_f'],
        'foodF'        => $r['food_f'],
        'afterF'       => $r['after_f'],
        'beforeL'      => $r['before_l'],
        'doseL'        => $r['dose_l'],
        'foodL'        => $r['food_l'],
        'afterL'       => $r['after_l'],
        'beforeD'      => $r['before_d'],
        'doseD'        => $r['dose_d'],
        'foodD'        => $r['food_d'],
        'afterD'       => $r['after_d'],
        'sleep'        => $r['sleep'],
        'totalInsulin' => $r['total_insulin'],
        'notes'        => $r['notes'],
    ];
}

// null للحقول الفاضية بدل string فاضي
function nv(string $v): ?float {
    $v = trim($v);
    return ($v === '' || $v === null) ? null : (float)$v;
}
