<?php
// ══════════════════════════════════════════════
//  api/auth.php — تسجيل الدخول والخروج
//  POST /api/auth.php?action=login   { username, password }
//  POST /api/auth.php?action=logout
//  POST /api/auth.php?action=register { username, password, name }
//  GET  /api/auth.php?action=me
// ══════════════════════════════════════════════
require_once __DIR__ . '/config.php';

$action = $_GET['action'] ?? '';
$body   = get_body();

// ──────────────────────────────────────────────
if ($action === 'login') {
    $username = trim($body['username'] ?? '');
    $password = $body['password'] ?? '';

    if (!$username || !$password) {
        json_out(['error' => 'أدخل اسم المستخدم والباسورد'], 400);
    }

    $pdo  = getDB();
    $stmt = $pdo->prepare('SELECT id, username, name, password_hash FROM users WHERE username = ?');
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        json_out(['error' => 'اسم المستخدم أو الباسورد غلط'], 401);
    }

    $_SESSION['user_id']   = $user['id'];
    $_SESSION['user_name'] = $user['name'];

    json_out(['ok' => true, 'user' => ['id' => $user['id'], 'name' => $user['name'], 'username' => $user['username']]]);
}

// ──────────────────────────────────────────────
if ($action === 'logout') {
    session_destroy();
    json_out(['ok' => true]);
}

// ──────────────────────────────────────────────
if ($action === 'register') {
    $username = trim($body['username'] ?? '');
    $password = $body['password'] ?? '';
    $name     = trim($body['name'] ?? '');

    if (!$username || !$password) {
        json_out(['error' => 'أدخل اسم مستخدم وباسورد'], 400);
    }
    if (strlen($password) < 6) {
        json_out(['error' => 'الباسورد لازم يكون 6 حروف على الأقل'], 400);
    }

    $pdo  = getDB();
    $hash = password_hash($password, PASSWORD_BCRYPT);

    try {
        $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, name) VALUES (?, ?, ?)');
        $stmt->execute([$username, $hash, $name ?: $username]);
        $userId = $pdo->lastInsertId();

        // إنشاء profile وgoals فارغة للمستخدم الجديد
        $pdo->prepare('INSERT INTO profile (user_id) VALUES (?)')->execute([$userId]);
        $pdo->prepare('INSERT INTO goals (user_id) VALUES (?)')->execute([$userId]);

        $_SESSION['user_id']   = $userId;
        $_SESSION['user_name'] = $name ?: $username;

        json_out(['ok' => true, 'user' => ['id' => $userId, 'name' => $name, 'username' => $username]], 201);
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            json_out(['error' => 'اسم المستخدم ده موجود بالفعل'], 409);
        }
        json_out(['error' => 'حصل خطأ: ' . $e->getMessage()], 500);
    }
}

// ──────────────────────────────────────────────
if ($action === 'me') {
    $uid  = getCurrentUserId();
    $pdo  = getDB();
    $stmt = $pdo->prepare('SELECT id, username, name, created_at FROM users WHERE id = ?');
    $stmt->execute([$uid]);
    $user = $stmt->fetch();
    json_out($user ?: ['error' => 'مش موجود'], $user ? 200 : 404);
}

json_out(['error' => 'action مش معروف'], 400);
