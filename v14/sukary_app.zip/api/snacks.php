<?php
// ══════════════════════════════════════════════
//  api/snacks.php
//  GET    /api/snacks.php             → كل السناكس
//  POST   /api/snacks.php             → إضافة سناك
//  PUT    /api/snacks.php?id=N        → تعديل
//  DELETE /api/snacks.php?id=N        → حذف
// ══════════════════════════════════════════════
require_once __DIR__ . '/config.php';

$uid    = getCurrentUserId();
$method = $_SERVER['REQUEST_METHOD'];
$pdo    = getDB();

if ($method === 'GET') {
    $stmt = $pdo->prepare(
        'SELECT * FROM snacks WHERE user_id = ? ORDER BY snack_date DESC, snack_time DESC'
    );
    $stmt->execute([$uid]);
    json_out(array_map('fmtSnack', $stmt->fetchAll()));
}

if ($method === 'POST') {
    $b    = get_body();
    $sql  = '
        INSERT INTO snacks
            (user_id, snack_date, snack_type, snack_time, sugar_before, food, carbs, dose, sugar_after, note)
        VALUES (?,?,?,?,?,?,?,?,?,?)
    ';
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $uid,
        $b['date']        ?? null,
        $b['type']        ?? null,
        $b['time']        ?? null,
        nv($b['sugarBefore'] ?? ''),
        $b['food']        ?? null,
        nv($b['carbs']    ?? ''),
        nv($b['dose']     ?? ''),
        nv($b['sugarAfter'] ?? ''),
        $b['note']        ?? null,
    ]);
    $newId = $pdo->lastInsertId();
    $stmt2 = $pdo->prepare('SELECT * FROM snacks WHERE id = ?');
    $stmt2->execute([$newId]);
    json_out(fmtSnack($stmt2->fetch()), 201);
}

if ($method === 'PUT') {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) json_out(['error' => 'id مطلوب'], 400);
    $b = get_body();
    $check = $pdo->prepare('SELECT id FROM snacks WHERE id = ? AND user_id = ?');
    $check->execute([$id, $uid]);
    if (!$check->fetch()) json_out(['error' => 'مش موجود'], 404);

    $stmt = $pdo->prepare('
        UPDATE snacks SET
            snack_date=?, snack_type=?, snack_time=?,
            sugar_before=?, food=?, carbs=?, dose=?, sugar_after=?, note=?
        WHERE id=? AND user_id=?
    ');
    $stmt->execute([
        $b['date'] ?? null, $b['type'] ?? null, $b['time'] ?? null,
        nv($b['sugarBefore'] ?? ''), $b['food'] ?? null,
        nv($b['carbs'] ?? ''), nv($b['dose'] ?? ''), nv($b['sugarAfter'] ?? ''),
        $b['note'] ?? null, $id, $uid
    ]);
    json_out(['ok' => true]);
}

if ($method === 'DELETE') {
    $id = (int)($_GET['id'] ?? 0);
    $stmt = $pdo->prepare('DELETE FROM snacks WHERE id = ? AND user_id = ?');
    $stmt->execute([$id, $uid]);
    json_out(['ok' => true]);
}

json_out(['error' => 'method مش مدعوم'], 405);

function fmtSnack(array $r): array {
    return [
        'id'         => (int)$r['id'],
        'date'       => $r['snack_date'],
        'type'       => $r['snack_type'],
        'time'       => $r['snack_time'],
        'sugarBefore'=> $r['sugar_before'],
        'food'       => $r['food'],
        'carbs'      => $r['carbs'],
        'dose'       => $r['dose'],
        'sugarAfter' => $r['sugar_after'],
        'note'       => $r['note'],
    ];
}
function nv(string $v): ?float {
    $v = trim($v);
    return ($v === '' || $v === null) ? null : (float)$v;
}
